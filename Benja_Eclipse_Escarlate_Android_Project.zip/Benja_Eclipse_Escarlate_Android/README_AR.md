# Benja – Eclipse Escarlate (Android)

هذا مشروع Android Studio لتغليف نسخة HTML المرفقة من اللعبة داخل تطبيق Android باستخدام WebView.
اللعبة تعمل من ملف محلي داخل التطبيق، لذلك لا تحتاج إلى استضافة أو اتصال إنترنت لتشغيل منطق اللعبة.

## إنشاء APK
1. ثبّت Android Studio على الكمبيوتر.
2. فك ضغط مجلد المشروع وافتح المجلد `Benja_Eclipse_Escarlate_Android` في Android Studio.
3. وافق على تثبيت Android SDK المطلوبة إذا طلب Android Studio ذلك.
4. انتظر انتهاء Gradle Sync.
5. اختر: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. بعد نجاح البناء اختر **locate** من إشعار Android Studio للوصول إلى ملف APK.
7. انقل APK إلى هاتف Android وثبّته. قد يطلب الهاتف السماح بالتثبيت من هذا المصدر.

## ملاحظات
- التطبيق مضبوط على الوضع الأفقي ويخفي أشرطة النظام أثناء اللعب.
- JavaScript وDOM Storage مفعّلان لدعم اللعبة وحفظ التقدم عبر localStorage.
- أضفت إذن الإنترنت فقط حتى يمكن تحميل خط Tajawal من Google Fonts عند توفر الشبكة؛ اللعبة نفسها وملفاتها الأساسية محلية.
- لم أتمكن من بناء APK نهائي في بيئة العمل الحالية لعدم توفر Android SDK وGradle؛ هذا مشروع المصدر الجاهز للبناء في Android Studio، وليس ملف APK مثبتاً أو مختبراً بعد.
